import { UPDATE_SORT } from './actionTypes';

export const updateSort = sort => ({
  type: UPDATE_SORT,
  payload: sort
});
